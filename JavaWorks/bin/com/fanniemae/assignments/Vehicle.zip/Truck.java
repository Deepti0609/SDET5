package com.fanniemae.assignments;

public class Truck extends Vehicle {
	
	
	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("Truck moves very fast");
		
	}
	public void axels(){
		System.out.println("Truck has different axels");
	}
	
	public void fuel(){
		System.out.println("Truck uses diesel");
	}
	

}
